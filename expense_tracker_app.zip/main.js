document.getElementById('expense-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const description = document.getElementById('description').value;
    const amount = document.getElementById('amount').value;
    addExpense(description, amount);

    document.getElementById('expense-form').reset();
});

function addExpense(description, amount) {
    const expenseList = document.getElementById('expense-list');
    const li = document.createElement('li');
    li.textContent = `${description}: $${amount}`;
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.onclick = function() {
        expenseList.removeChild(li);
    };
    li.appendChild(deleteButton);
    expenseList.appendChild(li);
}
